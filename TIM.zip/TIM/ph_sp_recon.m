%--------------------------------------------------------------------------
%                         相空间重构
%--------------------------------------------------------------------------
clc
clear all
%******************************读取数据*************************************

load .\data\KI07\N09_M07_F10_KI07_1.mat;
T1 = N09_M07_F10_KI07_1.Y(7).Data;
X_1 = T1(:,1:16:256000);

%% 载入转矩数据
T2 = N09_M07_F10_KI07_1.Y(6).Data;
X_2 = T2(:,1:16000);

%% 载入speed数据
T3 = N09_M07_F10_KI07_1.Y(4).Data;
X_3 = T3(:,1:16000);

%% 载入电流数据
T4 = N09_M07_F10_KI07_1.Y(3).Data;
X_4 = T4(:,1:16:256000);

%% 载入电流数据
T5 = N09_M07_F10_KI07_1.Y(1).Data;
X_5 = T5(:,1:16000);

max_d = 30;
mx1 = 0;
mx2 = 0;
mx3 = 0;
mx4 = 0;
mx5 = 0;
%%
[Smeanx1,Sdeltmeanx1,Scorx1,taux1,twx1]=CCMethod(X_1,max_d);
[Smeanx2,Sdeltmeanx2,Scorx2,taux2,twx2]=CCMethod(X_2,max_d);
[Smeanx3,Sdeltmeanx3,Scorx3,taux3,twx3]=CCMethod(X_3,max_d);
[Smeanx4,Sdeltmeanx4,Scorx4,taux4,twx4]=CCMethod(X_4,max_d);
[Smeanx5,Sdeltmeanx5,Scorx5,taux5,twx5]=CCMethod(X_5,max_d);
mx1 = twx1/taux1 + 1;
if mx1 >= 2 && mx1 <= 5
    mx1 = round(twx1/taux1 + 1);
else
    mx1 = 5;
end

mx2 = twx2/taux2 + 1;
if mx2 >= 2 && mx2 <= 5
    mx2 = round(twx2/taux2 + 1);
else
    mx2 = 5;
end

mx3 = twx3/taux3 + 1;
if mx3 >= 2 && mx3 <= 5
    mx3 = round(twx3/taux3 + 1);
else
    mx3 = 5;
end

mx4 = twx4/taux4 + 1;
if mx4 >= 2 && mx4 <= 5
    mx4 = round(twx4/taux4 + 1);
else
    mx4 = 5;
end

mx5 = twx5/taux5 + 1;
if mx5 >= 2 && mx5 <= 5
    mx5 = round(twx5/taux5 + 1);
else
    mx5 = 5;
end

Data1=reconstitution(X_1,mx1,taux1);
Data2=reconstitution(X_2,mx2,taux2);
Data3=reconstitution(X_3,mx3,taux3);
Data4=reconstitution(X_4,mx4,taux4);
Data5=reconstitution(X_5,mx5,taux5);

save('KI07_1_vibration_ph','Data1');
save('KI07_1_torque_ph','Data2');
save('KI07_1_speed_ph','Data3');
save('KI07_1_current_ph','Data4');
save('KI07_1_force_ph','Data5');

xlswrite('KI07_1_vibration_ph.xlsx',Data1);
xlswrite('KI07_1_torque_ph.xlsx',Data2);
xlswrite('KI07_1_speed_ph.xlsx',Data3);
xlswrite('KI07_1_current_ph.xlsx',Data4);
xlswrite('KI07_1_force_ph.xlsx',Data5);

xlswrite('KI07_1_vibration.xlsx',X_1);
xlswrite('KI07_1_torque.xlsx',X_2);
xlswrite('KI07_1_speed.xlsx',X_3);
xlswrite('KI07_1_current.xlsx',X_4);
xlswrite('KI07_1_force.xlsx',X_5);