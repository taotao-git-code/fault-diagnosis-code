import numpy as np
from scipy.stats import entropy
from itertools import combinations
import networkx as nx
import matplotlib.pyplot as plt


class ChowLiuTree:
    def __init__(self, data):
        """
        Initialize Chow-Liu Tree algorithm with dataset
        data: numpy array of shape (n_samples, n_features)
        """
        self.data = data
        self.n_features = data.shape[1]
        self.tree = None
        
    def compute_mutual_information(self, i, j):
        """
        Compute mutual information between two variables
        """
        # Get columns for variables i and j
        xi = self.data[:, i]
        xj = self.data[:, j]
        
        # Compute joint probability distribution
        joint_dist = np.histogram2d(xi, xj, bins=[np.unique(xi).size, np.unique(xj).size])[0]
        joint_dist = joint_dist / joint_dist.sum()
        
        # Compute marginal distributions
        pi = joint_dist.sum(axis=1)
        pj = joint_dist.sum(axis=0)
        
        # Compute mutual information
        mi = 0
        for ii in range(joint_dist.shape[0]):
            for jj in range(joint_dist.shape[1]):
                if joint_dist[ii,jj] > 0:
                    mi += joint_dist[ii,jj] * np.log(joint_dist[ii,jj] / (pi[ii] * pj[jj]))
        return mi
        
    def build_tree(self):
        """
        Build the Chow-Liu tree using maximum spanning tree
        """
        # Create graph
        G = nx.Graph()
        
        # Compute mutual information between all pairs of variables
        for i, j in combinations(range(self.n_features), 2):
            mi = self.compute_mutual_information(i, j)
            G.add_edge(i, j, weight=mi)
            
        # Find maximum spanning tree
        self.tree = nx.maximum_spanning_tree(G)
        return self.tree
    
    def get_edges(self):
        """
        Return the edges of the tree
        """
        if self.tree is None:
            self.build_tree()
        return list(self.tree.edges())

def example_usage():
    # Generate some random data
    np.random.seed(42)
    n_samples = 1000
    n_features = 5
    data = np.random.randint(0, 3, size=(n_samples, n_features))
    
    # Create and build Chow-Liu tree
    cl_tree = ChowLiuTree(data)
    tree = cl_tree.build_tree()
    
    # Print edges
    print("Tree edges:", cl_tree.get_edges())
    
    # Visualize tree
    pos = nx.spring_layout(tree)
    nx.draw(tree, pos, with_labels=True, node_color='lightblue', 
            node_size=500, font_size=16, font_weight='bold')
    edge_labels = nx.get_edge_attributes(tree, 'weight')
    nx.draw_networkx_edge_labels(tree, pos, edge_labels)
    plt.show()

if __name__ == "__main__":
    example_usage()
