clc
clear all
close all

%% 载入数据
% 载入振动数据
load .\data\KA09\N09_M07_F10_KA09_1.mat;
T1 = N09_M07_F10_KA09_1.Y(7).Data;
X_1 = T1(:,1:16:256000);

% 载入转矩数据
T2 = N09_M07_F10_KA09_1.Y(6).Data;
X_2 = T2(:,1:16000);

% 载入speed数据
T3 = N09_M07_F10_KA09_1.Y(4).Data;
X_3 = T3(:,1:16000);

% 载入电流数据
T4 = N09_M07_F10_KA09_1.Y(3).Data;
X_4 = T4(:,1:16:256000);

% 载入电流数据
T5 = N09_M07_F10_KA09_1.Y(1).Data;
X_5 = T5(:,1:16000);

y = xlsread('KI17_1_torque_ph.xlsx');%
x = xlsread('KI17_1_vibration_ph.xlsx');
y=y(1,1:15970);
x=x(1,1:15970);

% 载入相空间重构数据
x_1 = xlsread('KA09_1_vibration_ph.xlsx');%
x_2 = xlsread('KA09_1_torque_ph.xlsx');
x_3 = xlsread('KI17_1_speed_ph.xlsx');
x_4 = xlsread('KI17_1_force_ph.xlsx');
x_5 = xlsread('KI17_1_current_ph.xlsx');
%
Dataset = [x_1(1,1:15900)' x_2(1,1:15900)'];
% Dataset = [x' y'/1000];
%%
U3 = Dataset(:,2);
max_U3 = max(abs(U3));
U3 = U3./max_U3;

H = Dataset(:,1);
max_H = max(abs(H));
H = H./max_H;

%% Pearson r
sumU3 = sum(abs(U3))/size(U3,1);
reference = abs(U3)-sumU3;
varreference = sqrt(var(reference));

%% Spearman's rho
[huy_s,huy_i] = sort(abs(U3));
R_huy = zeros(size(U3,1),size(U3,2));

for rank = 1:size(huy_i,1)
    R_huy(huy_i(rank,1),1) = rank;
end

%% Kendall's tau
T_huy = zeros(size(U3,1),size(U3,1));
for ver = 1:size(T_huy,1)
    for hor = ver:size(T_huy,2)
        T_huy(ver,hor) = sign(abs(U3(ver,1))-abs(U3(hor,1)));
    end
end


%% calculate r
sumH = sum(abs(H))/size(H,1);
compare = abs(H)-sumH;
varcompare = sqrt(var(compare));

cross_correlation = sum(reference.*compare)/varreference/varcompare/30;
H_crr_error = cross_correlation;

display(['Pearson test correlation value:',num2str(H_crr_error)])

%% calculate rho
[hyb_s,hyb_i] = sort(abs(H));
R_hyb = zeros(size(H,1),size(H,2));

for rank = 1:size(hyb_i,1)
    R_hyb(hyb_i(rank,1),1) = rank;
end

H_rho_error = 1-(6*sum((R_huy-R_hyb).^2))/(size(H,1)*(size(H,1)^2-1));
display(['Spearman test correlation value:',num2str(H_rho_error)])


%% calculate tau
discordance = 0;
concordance = 0;
T_hyb = zeros(size(U3,1),size(U3,1));
for ver = 1:size(T_hyb,1)
    for hor = ver:size(T_hyb,2)
        T_hyb(ver,hor) = sign(abs(H(ver,1))-abs(H(hor,1)));
        D = abs(T_huy(ver,hor)-T_hyb(ver,hor));
        C = abs(T_huy(ver,hor)+T_hyb(ver,hor));
        if D ==2
            discordance = discordance+1;
        elseif C ==2
            concordance = concordance+1;
        end
    end
end


H_tau_error = (concordance-discordance)/(size(H,1)*(size(H,1)-1))*2;
display(['Kendall test correlation value:',num2str(H_tau_error)])
