clc
clear all
close all
addpath(genpath(fileparts(mfilename('fullpath'))));

Params = Config();
rng('default')
rng(Params.random_seed)
A=load('Original_data/K001/N15_M07_F10_K001_1.mat');%N15_M07_F10
a =A. N15_M07_F10_K001_1.Y(4).Data;
a=a(1:10240);
% Sig=atan(a')*(2/pi)
% Sig=log10(a')/log10(max(a'))%%
% Sig = a'
Sig=zscore(a')
% [ Sig , t] = Generate_Simulation(Params);


%% Estimate the energy of the noise
NoiseSigma = NoiseEstimate(Sig);
%% Perform weighted multi-scale dictionary learning ��߶��ֵ�ѧϰ
Params.init_E = Params.init_E * NoiseSigma;
tic
[y_WMSDL] = WMSDL(Sig, Params);
time_WMSDL = toc;
%% Perform KSVD denoising  ����KSVDȥ��
Params.n = 200;
Params.m = Params.n * 2;
Params.E = 19.5 * NoiseSigma * getConstant(Params.n);
tic
[y_KSVD] = CleanKSVD(Sig, Params);
time_KSVD = toc;
%% Perform the square envelope spectrum (SES)���ΰ�����
[ yf_WMSDL, ~ ] = Hilbert_envelope( y_WMSDL , Params.Fs , 1);
[ yf_KSVD, f ] = Hilbert_envelope( y_KSVD , Params.Fs , 1);
%% Plot the results
figure
subplot(311)
% plot(t, Sig)
plot(f(1:10:8000),Sig(1:10:8000))
title('Original Signal')
ylabel('Amp (g)')
subplot(312)
% figure
% plot(t, y_WMSDL)
plot(f(1:10:8000), y_WMSDL(1:10:8000))
title(['AdaSpare, Computational time = ' num2str(time_WMSDL) 's'])
ylabel('Amp (g)')
subplot(313)
% figure
% plot(t, y_KSVD)
plot(f(1:10:8000), y_KSVD(1:10:8000))
title(['KSVD, Computational time = ' num2str(time_KSVD) 's'])
ylabel('Amp (g)')
xlabel('Time (s)')
filename = ['Results_original data', filesep, sprintf('N15_M07_F10_K001_1_speed.pdf')];
print(filename, '-dpdf');

figure
subplot(211)
plot(f(1:10:8000), yf_WMSDL(1:10:8000))
title(['AdaSpare, Computational time = ' num2str(time_WMSDL) 's'])
ylabel('Amp (g)')
subplot(212)
% figure
plot(f(1:10:8000), yf_KSVD(1:10:8000))
title(['KSVD, Computational time = ' num2str(time_KSVD) 's'])
ylabel('Amp (g)')
xlabel('Frequency (Hz)')
filename = ['Results_original data', filesep, sprintf('N15_M07_F10_K001_1_speed_SES.pdf')];
print(filename, '-dpdf');