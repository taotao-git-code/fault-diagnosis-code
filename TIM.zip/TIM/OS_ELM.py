import numpy as np
from sklearn.preprocessing import StandardScaler
import random
import time

class OS_ELM:
    def __init__(self, hidden_neurons, activation='sigmoid'):
        self.hidden_neurons = hidden_neurons
        self.activation = activation
        self.input_weights = None
        self.biases = None
        self.output_weights = None
        self.P = None
        
    def _sigmoid(self, x):
        return 1 / (1 + np.exp(-x))
    
    def _relu(self, x):
        return np.maximum(0, x)
        
    def _activate(self, x):
        if self.activation == 'sigmoid':
            return self._sigmoid(x)
        elif self.activation == 'relu':
            return self._relu(x)
            
    def initialize(self, X, y):
        input_dim = X.shape[1]
        output_dim = y.shape[1] if len(y.shape) > 1 else 1
        
        # Randomly initialize input weights and biases
        self.input_weights = np.random.uniform(-1, 1, (input_dim, self.hidden_neurons))
        self.biases = np.random.uniform(-1, 1, self.hidden_neurons)
        
        # Calculate hidden layer output
        temp_H = np.dot(X, self.input_weights) + self.biases
        H = self._activate(temp_H)
        
        # Calculate output weights using Moore-Penrose pseudo-inverse
        self.output_weights = np.dot(np.linalg.pinv(H), y)
        
        # Calculate P matrix for sequential learning
        self.P = np.linalg.inv(np.dot(H.T, H))
        
    def fit(self, X, y):
        # Calculate hidden layer output
        temp_H = np.dot(X, self.input_weights) + self.biases
        H = self._activate(temp_H)
        
        # Update P matrix and output weights
        temp = np.dot(self.P, H.T)
        self.P = self.P - np.dot(np.dot(temp, H), self.P) / (1 + np.dot(np.dot(H, self.P), H.T))
        self.output_weights = self.output_weights + np.dot(np.dot(self.P, H.T), (y - np.dot(H, self.output_weights)))
        
    def predict(self, X):
        # Calculate hidden layer output
        temp_H = np.dot(X, self.input_weights) + self.biases
        H = self._activate(temp_H)
        
        # Calculate predictions
        predictions = np.dot(H, self.output_weights)
        return predictions
