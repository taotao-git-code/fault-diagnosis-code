%%
clc
clear all

%% C-C方法的主程序
% data=xlsread('all_data7.xlsx','all_data','b1:b20000');
load .\data\KI17\N09_M07_F10_KI17_1.mat;
T1 = N09_M07_F10_KI17_1.Y(6).Data;
data = T1(:,1:1600);

[ACF,lags,bounds]=autocorr(data,100);
tau=59;
m=15;
[D,MEAN,STD]=zscore(data);
r1=0.5*STD;
N=length(data);
% [a,b]=find(ACF<ACF(1)*(1-exp(-1))); %自相关系数
beifen=data;

%% 求统计量S
SS=[];     %均值
DTS=[];    %Delta 最大值和最小值差
COR=[];    %
T=[];
NN=1:6000;

for t=1:100
   sums=0;
   sumdts=0;
%     if mod(N,t)~=0
%         [a,b]=find(mod(NN,t)==0);
%         data=beifen(1:b(end));
%     end
       for i=1:t
           eval(['datat',num2str(i),'=[];'])
           for j=1:N/t
               eval(['tran=data(',num2str(i),'+',num2str(t),'*(',num2str(j),'-1));'])
               eval(['datat',num2str(i),'=[datat',num2str(i),';tran];'])
           end
       end
       for m=2:5
           ds=[];
           for k=1:4
               S=[];
               for i=1:t
                   eval(['S',num2str(i),'=[];'])
                   eval(['datat=datat',num2str(i),';'])
                   r=r1*k;
                   C1=C(m,N/t,r,t,datat);%%计算关联积分
                   C2=C(1,N/t,r,t,datat);
                   eval(['S',num2str(i),'=[S',num2str(i),',C1-C2];'])%% 计算检验统计量
                   eval(['S=[S;S',num2str(i),'];'])
               end
               S=sum(S)/t;
               ds=[ds,S];
               sums=sums+S;
           end
%            dts=max(ds)-min(ds);%% 求ΔS
           dts=ds(end)-ds(1);
           sumdts=sumdts+dts;
       end
       sums=sums/16;
       sumdts=sumdts/4;
       scor=sumdts+abs(sums);
       T=[T;t];
    S=S/t;
   SS=[SS;sums];
   DTS=[DTS;sumdts];
   COR=[COR;scor];
end
%%
xieru=["datat1","datat2","datat3","datat4","datat5","datat6","datat7","datat8","datat9","datat10","datat11","datat12","datat13","datat14","datat15","datat16"];
for i=1:16
    eval(['tran=datat',num2str(i),';'])
    xlswrite('xkjcg.xlsx',tran,xieru(i));
end
tt=1:100;
plot(tt,SS,tt,DTS,tt,COR)
legend('SS','DTS','COR')

