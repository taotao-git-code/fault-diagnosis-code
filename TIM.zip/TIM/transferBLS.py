import numpy as np
from sklearn.preprocessing import StandardScaler

class TransferBLS:
    def __init__(self, n_feature_nodes=10, n_enhancement_nodes=10, feature_windows=10):
        self.n_feature_nodes = n_feature_nodes
        self.n_enhancement_nodes = n_enhancement_nodes 
        self.feature_windows = feature_windows
        self.feature_weights = []
        self.enhancement_weights = []
        self.output_weights = None
        self.scaler = StandardScaler()
        
    def generate_random_weights(self, m, n):
        return (2.0 * np.random.random([m, n]) - 1.0)

    def generate_feature_nodes(self, X):
        feature_nodes = []
        for i in range(self.feature_windows):
            weight = self.generate_random_weights(X.shape[1], self.n_feature_nodes)
            self.feature_weights.append(weight)
            feature_node = np.dot(X, weight)
            feature_node = self.scaler.fit_transform(feature_node)
            feature_nodes.append(feature_node)
        return np.concatenate(feature_nodes, axis=1)

    def generate_enhancement_nodes(self, feature_nodes):
        enhancement_nodes = []
        for i in range(self.n_enhancement_nodes):
            weight = self.generate_random_weights(feature_nodes.shape[1], 1)
            self.enhancement_weights.append(weight)
            enhancement_node = np.dot(feature_nodes, weight)
            enhancement_node = self.scaler.fit_transform(enhancement_node)
            enhancement_nodes.append(enhancement_node)
        return np.concatenate(enhancement_nodes, axis=1)

    def fit(self, X, y):
        # Generate feature nodes
        feature_nodes = self.generate_feature_nodes(X)
        
        # Generate enhancement nodes
        enhancement_nodes = self.generate_enhancement_nodes(feature_nodes)
        
        # Combine feature and enhancement nodes
        training_data = np.concatenate([feature_nodes, enhancement_nodes], axis=1)
        
        # Calculate output weights using pseudoinverse
        self.output_weights = np.dot(np.linalg.pinv(training_data), y)
        
    def predict(self, X):
        # Generate feature nodes using stored weights
        feature_nodes = []
        for weight in self.feature_weights:
            feature_node = np.dot(X, weight)
            feature_node = self.scaler.transform(feature_node)
            feature_nodes.append(feature_node)
        feature_nodes = np.concatenate(feature_nodes, axis=1)
        
        # Generate enhancement nodes using stored weights
        enhancement_nodes = []
        for weight in self.enhancement_weights:
            enhancement_node = np.dot(feature_nodes, weight)
            enhancement_node = self.scaler.transform(enhancement_node)
            enhancement_nodes.append(enhancement_node)
        enhancement_nodes = np.concatenate(enhancement_nodes, axis=1)
        
        # Combine nodes and predict
        test_data = np.concatenate([feature_nodes, enhancement_nodes], axis=1)
        return np.dot(test_data, self.output_weights)

    def transfer_knowledge(self, source_model):
        """Transfer knowledge from a source model"""
        self.feature_weights = source_model.feature_weights.copy()
        self.enhancement_weights = source_model.enhancement_weights.copy()
        # Only fine-tune output weights on target domain
